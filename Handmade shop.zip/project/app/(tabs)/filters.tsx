import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
} from 'react-native';
import { ChevronDown, ChevronUp, Filter, RotateCcw } from 'lucide-react-native';
import Animated, {
  FadeInDown,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import Slider from '@react-native-community/slider';

const categories = [
  'All Categories',
  'Dresses',
  'Tops',
  'Accessories',
  'Jewelry',
  'Bags',
  'Shoes',
];

const colors = [
  { name: 'Red', color: '#DC143C' },
  { name: 'Pink', color: '#FF69B4' },
  { name: 'Yellow', color: '#FFFACD' },
  { name: 'Blue', color: '#4169E1' },
  { name: 'Green', color: '#32CD32' },
  { name: 'Purple', color: '#9370DB' },
  { name: 'Black', color: '#000000' },
  { name: 'White', color: '#FFFFFF' },
];

const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

const materials = [
  'Cotton',
  'Silk',
  'Wool',
  'Linen',
  'Leather',
  'Cashmere',
  'Polyester',
];

export default function FiltersScreen() {
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState([0, 500]);
  const [showOnSale, setShowOnSale] = useState(false);
  const [showNewArrivals, setShowNewArrivals] = useState(false);
  const [showHandpicked, setShowHandpicked] = useState(false);
  
  const [expandedSections, setExpandedSections] = useState({
    category: true,
    price: true,
    colors: false,
    sizes: false,
    materials: false,
    special: false,
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const toggleSelection = (
    items: string[],
    setItems: React.Dispatch<React.SetStateAction<string[]>>,
    item: string
  ) => {
    if (items.includes(item)) {
      setItems(items.filter(i => i !== item));
    } else {
      setItems([...items, item]);
    }
  };

  const resetAllFilters = () => {
    setSelectedCategory('All Categories');
    setSelectedColors([]);
    setSelectedSizes([]);
    setSelectedMaterials([]);
    setPriceRange([0, 500]);
    setShowOnSale(false);
    setShowNewArrivals(false);
    setShowHandpicked(false);
  };

  const FilterSection = ({ 
    title, 
    sectionKey, 
    children 
  }: { 
    title: string; 
    sectionKey: string; 
    children: React.ReactNode;
  }) => {
    const isExpanded = expandedSections[sectionKey as keyof typeof expandedSections];
    
    return (
      <Animated.View
        entering={FadeInDown.springify()}
        style={styles.filterSection}
      >
        <TouchableOpacity
          style={styles.sectionHeader}
          onPress={() => toggleSection(sectionKey)}
        >
          <Text style={styles.sectionTitle}>{title}</Text>
          {isExpanded ? (
            <ChevronUp size={20} color="#8B0000" />
          ) : (
            <ChevronDown size={20} color="#8B0000" />
          )}
        </TouchableOpacity>
        {isExpanded && <View style={styles.sectionContent}>{children}</View>}
      </Animated.View>
    );
  };

  return (
    <LinearGradient
      colors={['#FF69B4', '#FFB6C1', '#FFC0CB']}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Filter size={24} color="#8B0000" />
          <Text style={styles.headerTitle}>Filters</Text>
        </View>
        <TouchableOpacity onPress={resetAllFilters} style={styles.resetButton}>
          <RotateCcw size={18} color="#DC143C" />
          <Text style={styles.resetText}>Reset</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Category Filter */}
        <FilterSection title="Category" sectionKey="category">
          <View style={styles.categoryGrid}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category}
                style={[
                  styles.categoryButton,
                  selectedCategory === category && styles.selectedCategoryButton,
                ]}
                onPress={() => setSelectedCategory(category)}
              >
                <Text
                  style={[
                    styles.categoryButtonText,
                    selectedCategory === category && styles.selectedCategoryButtonText,
                  ]}
                >
                  {category}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </FilterSection>

        {/* Price Range Filter */}
        <FilterSection title="Price Range" sectionKey="price">
          <View style={styles.priceContainer}>
            <View style={styles.priceLabels}>
              <Text style={styles.priceLabel}>${priceRange[0]}</Text>
              <Text style={styles.priceLabel}>${priceRange[1]}</Text>
            </View>
            <Slider
              style={styles.slider}
              minimumValue={0}
              maximumValue={500}
              value={priceRange[1]}
              onValueChange={(value) => setPriceRange([priceRange[0], Math.round(value)])}
              minimumTrackTintColor="#DC143C"
              maximumTrackTintColor="#FFB6C1"
              thumbStyle={{ backgroundColor: '#8B0000' }}
            />
          </View>
        </FilterSection>

        {/* Colors Filter */}
        <FilterSection title="Colors" sectionKey="colors">
          <View style={styles.colorGrid}>
            {colors.map((colorItem) => (
              <TouchableOpacity
                key={colorItem.name}
                style={[
                  styles.colorButton,
                  { backgroundColor: colorItem.color },
                  selectedColors.includes(colorItem.name) && styles.selectedColorButton,
                ]}
                onPress={() => toggleSelection(selectedColors, setSelectedColors, colorItem.name)}
              >
                {selectedColors.includes(colorItem.name) && (
                  <View style={styles.colorCheckmark} />
                )}
              </TouchableOpacity>
            ))}
          </View>
        </FilterSection>

        {/* Sizes Filter */}
        <FilterSection title="Sizes" sectionKey="sizes">
          <View style={styles.sizeGrid}>
            {sizes.map((size) => (
              <TouchableOpacity
                key={size}
                style={[
                  styles.sizeButton,
                  selectedSizes.includes(size) && styles.selectedSizeButton,
                ]}
                onPress={() => toggleSelection(selectedSizes, setSelectedSizes, size)}
              >
                <Text
                  style={[
                    styles.sizeButtonText,
                    selectedSizes.includes(size) && styles.selectedSizeButtonText,
                  ]}
                >
                  {size}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </FilterSection>

        {/* Materials Filter */}
        <FilterSection title="Materials" sectionKey="materials">
          <View style={styles.materialGrid}>
            {materials.map((material) => (
              <TouchableOpacity
                key={material}
                style={[
                  styles.materialButton,
                  selectedMaterials.includes(material) && styles.selectedMaterialButton,
                ]}
                onPress={() => toggleSelection(selectedMaterials, setSelectedMaterials, material)}
              >
                <Text
                  style={[
                    styles.materialButtonText,
                    selectedMaterials.includes(material) && styles.selectedMaterialButtonText,
                  ]}
                >
                  {material}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </FilterSection>

        {/* Special Filters */}
        <FilterSection title="Special Filters" sectionKey="special">
          <View style={styles.specialFilters}>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>On Sale</Text>
              <Switch
                trackColor={{ false: '#FFB6C1', true: '#DC143C' }}
                thumbColor={showOnSale ? '#FFFACD' : '#8B0000'}
                value={showOnSale}
                onValueChange={setShowOnSale}
              />
            </View>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>New Arrivals</Text>
              <Switch
                trackColor={{ false: '#FFB6C1', true: '#DC143C' }}
                thumbColor={showNewArrivals ? '#FFFACD' : '#8B0000'}
                value={showNewArrivals}
                onValueChange={setShowNewArrivals}
              />
            </View>
            <View style={styles.switchRow}>
              <Text style={styles.switchLabel}>Handpicked</Text>
              <Switch
                trackColor={{ false: '#FFB6C1', true: '#DC143C' }}
                thumbColor={showHandpicked ? '#FFFACD' : '#8B0000'}
                value={showHandpicked}
                onValueChange={setShowHandpicked}
              />
            </View>
          </View>
        </FilterSection>

        {/* Apply Filters Button */}
        <Animated.View
          entering={FadeInDown.delay(600).springify()}
          style={styles.applyButtonContainer}
        >
          <TouchableOpacity style={styles.applyButton}>
            <Text style={styles.applyButtonText}>Apply Filters</Text>
          </TouchableOpacity>
        </Animated.View>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#8B0000',
    marginLeft: 10,
  },
  resetButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
  },
  resetText: {
    fontSize: 14,
    color: '#DC143C',
    fontWeight: '600',
    marginLeft: 4,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  filterSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8B0000',
  },
  sectionContent: {
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  categoryButton: {
    backgroundColor: '#FFB6C1',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    marginBottom: 10,
  },
  selectedCategoryButton: {
    backgroundColor: '#DC143C',
  },
  categoryButtonText: {
    fontSize: 14,
    color: '#8B0000',
    fontWeight: '500',
  },
  selectedCategoryButtonText: {
    color: '#FFFACD',
    fontWeight: '600',
  },
  priceContainer: {
    paddingVertical: 10,
  },
  priceLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  priceLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#8B0000',
  },
  slider: {
    width: '100%',
    height: 40,
  },
  colorGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  colorButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedColorButton: {
    borderColor: '#8B0000',
    borderWidth: 3,
  },
  colorCheckmark: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#8B0000',
  },
  sizeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  sizeButton: {
    backgroundColor: '#FFB6C1',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 15,
    minWidth: 50,
    alignItems: 'center',
  },
  selectedSizeButton: {
    backgroundColor: '#DC143C',
  },
  sizeButtonText: {
    fontSize: 14,
    color: '#8B0000',
    fontWeight: '500',
  },
  selectedSizeButtonText: {
    color: '#FFFACD',
    fontWeight: '600',
  },
  materialGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  materialButton: {
    backgroundColor: '#FFB6C1',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 15,
  },
  selectedMaterialButton: {
    backgroundColor: '#DC143C',
  },
  materialButtonText: {
    fontSize: 13,
    color: '#8B0000',
    fontWeight: '500',
  },
  selectedMaterialButtonText: {
    color: '#FFFACD',
    fontWeight: '600',
  },
  specialFilters: {
    gap: 15,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  switchLabel: {
    fontSize: 16,
    color: '#8B0000',
    fontWeight: '500',
  },
  applyButtonContainer: {
    marginTop: 20,
  },
  applyButton: {
    backgroundColor: '#DC143C',
    paddingVertical: 18,
    borderRadius: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 8,
  },
  applyButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFACD',
  },
  bottomSpacer: {
    height: 100,
  },
});