import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  Dimensions,
} from 'react-native';
import { Search, Heart, Star, TrendingUp } from 'lucide-react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  FadeInDown,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const featuredItems = [
  {
    id: 1,
    name: 'Silk Evening Dress',
    price: '$299',
    image: 'https://images.pexels.com/photos/1936848/pexels-photo-1936848.jpeg',
    rating: 4.9,
    category: 'Dresses',
  },
  {
    id: 2,
    name: 'Handwoven Scarf',
    price: '$89',
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg',
    rating: 4.8,
    category: 'Accessories',
  },
  {
    id: 3,
    name: 'Artisan Jewelry Set',
    price: '$159',
    image: 'https://images.pexels.com/photos/1927259/pexels-photo-1927259.jpeg',
    rating: 5.0,
    category: 'Jewelry',
  },
];

const categories = [
  { name: 'Dresses', icon: '👗', count: 24 },
  { name: 'Accessories', icon: '👜', count: 18 },
  { name: 'Jewelry', icon: '💎', count: 32 },
  { name: 'Tops', icon: '👕', count: 15 },
];

export default function HomeScreen() {
  const scaleValue = useSharedValue(0);
  const fadeValue = useSharedValue(0);

  useEffect(() => {
    scaleValue.value = withSpring(1, { damping: 15, stiffness: 150 });
    fadeValue.value = withTiming(1, { duration: 800 });
  }, []);

  const headerAnimatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scaleValue.value }],
      opacity: fadeValue.value,
    };
  });

  return (
    <LinearGradient
      colors={['#FF69B4', '#FFB6C1', '#FFC0CB']}
      style={styles.container}
    >
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Animated.View style={[styles.header, headerAnimatedStyle]}>
          <View style={styles.headerContent}>
            <Text style={styles.greeting}>Hello, Beautiful!</Text>
            <Text style={styles.subtitle}>Discover handcrafted luxury</Text>
          </View>
          <TouchableOpacity style={styles.heartButton}>
            <Heart size={24} color="#8B0000" />
          </TouchableOpacity>
        </Animated.View>

        {/* Search Bar */}
        <Animated.View
          entering={FadeInDown.delay(200).springify()}
          style={styles.searchContainer}
        >
          <View style={styles.searchBar}>
            <Search size={20} color="#8B0000" />
            <TextInput
              placeholder="Search handmade treasures..."
              placeholderTextColor="#CD5C5C"
              style={styles.searchInput}
            />
          </View>
        </Animated.View>

        {/* Categories */}
        <Animated.View
          entering={FadeInDown.delay(400).springify()}
          style={styles.section}
        >
          <Text style={styles.sectionTitle}>Categories</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {categories.map((category, index) => (
              <TouchableOpacity key={category.name} style={styles.categoryCard}>
                <Text style={styles.categoryIcon}>{category.icon}</Text>
                <Text style={styles.categoryName}>{category.name}</Text>
                <Text style={styles.categoryCount}>{category.count} items</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </Animated.View>

        {/* Trending Now */}
        <Animated.View
          entering={FadeInDown.delay(600).springify()}
          style={styles.section}
        >
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Trending Now</Text>
            <TrendingUp size={20} color="#DC143C" />
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {featuredItems.map((item, index) => (
              <TouchableOpacity key={item.id} style={styles.productCard}>
                <Image source={{ uri: item.image }} style={styles.productImage} />
                <View style={styles.productInfo}>
                  <Text style={styles.productName}>{item.name}</Text>
                  <Text style={styles.productCategory}>{item.category}</Text>
                  <View style={styles.productFooter}>
                    <Text style={styles.productPrice}>{item.price}</Text>
                    <View style={styles.rating}>
                      <Star size={12} color="#FFFACD" fill="#FFFACD" />
                      <Text style={styles.ratingText}>{item.rating}</Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </Animated.View>

        {/* Featured Banner */}
        <Animated.View
          entering={FadeInDown.delay(800).springify()}
          style={styles.bannerContainer}
        >
          <LinearGradient
            colors={['#DC143C', '#B22222']}
            style={styles.banner}
          >
            <View style={styles.bannerContent}>
              <Text style={styles.bannerTitle}>Exclusive Collection</Text>
              <Text style={styles.bannerSubtitle}>Limited edition handcrafted pieces</Text>
              <TouchableOpacity style={styles.bannerButton}>
                <Text style={styles.bannerButtonText}>Shop Now</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </Animated.View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerContent: {
    flex: 1,
  },
  greeting: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#8B0000',
    opacity: 0.8,
  },
  heartButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FFFACD',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchContainer: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 25,
    paddingHorizontal: 20,
    paddingVertical: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: '#8B0000',
  },
  section: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#8B0000',
    flex: 1,
  },
  categoryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 15,
    padding: 20,
    marginLeft: 20,
    alignItems: 'center',
    minWidth: 100,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  categoryIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#8B0000',
    marginBottom: 4,
  },
  categoryCount: {
    fontSize: 12,
    color: '#CD5C5C',
  },
  productCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    marginLeft: 20,
    width: width * 0.7,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 8,
  },
  productImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  productInfo: {
    padding: 15,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 14,
    color: '#CD5C5C',
    marginBottom: 10,
  },
  productFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  productPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#DC143C',
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#8B0000',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },
  ratingText: {
    fontSize: 12,
    color: '#FFFACD',
    marginLeft: 4,
    fontWeight: '600',
  },
  bannerContainer: {
    paddingHorizontal: 20,
    marginBottom: 40,
  },
  banner: {
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 8,
  },
  bannerContent: {
    padding: 30,
    alignItems: 'center',
  },
  bannerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFACD',
    marginBottom: 8,
    textAlign: 'center',
  },
  bannerSubtitle: {
    fontSize: 16,
    color: '#FFFACD',
    opacity: 0.9,
    textAlign: 'center',
    marginBottom: 20,
  },
  bannerButton: {
    backgroundColor: '#FFFACD',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  bannerButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#8B0000',
  },
});