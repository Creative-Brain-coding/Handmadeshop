import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Switch,
} from 'react-native';
import { User, Heart, Settings, ShoppingBag, Bell, CreditCard, MapPin, CircleHelp as HelpCircle, LogOut, ChevronRight, Star, Award } from 'lucide-react-native';
import Animated, {
  FadeInDown,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

const menuItems = [
  { icon: Heart, title: 'Wishlist', subtitle: '12 items', color: '#DC143C' },
  { icon: ShoppingBag, title: 'Orders', subtitle: '3 active orders', color: '#8B0000' },
  { icon: CreditCard, title: 'Payment Methods', subtitle: 'Manage cards', color: '#B22222' },
  { icon: MapPin, title: 'Addresses', subtitle: '2 saved addresses', color: '#CD5C5C' },
  { icon: Bell, title: 'Notifications', subtitle: 'Push notifications', color: '#DC143C' },
  { icon: HelpCircle, title: 'Help & Support', subtitle: 'FAQs & Contact', color: '#8B0000' },
  { icon: Settings, title: 'Settings', subtitle: 'App preferences', color: '#B22222' },
];

const achievements = [
  { title: 'First Purchase', icon: '🛍️', earned: true },
  { title: 'Review Master', icon: '⭐', earned: true },
  { title: 'Fashion Lover', icon: '👗', earned: false },
  { title: 'VIP Member', icon: '💎', earned: false },
];

export default function ProfileScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const scaleValue = useSharedValue(1);

  const MenuItem = ({ item, index }: { item: any; index: number }) => (
    <Animated.View
      entering={FadeInDown.delay(index * 100).springify()}
    >
      <TouchableOpacity style={styles.menuItem}>
        <View style={[styles.menuIcon, { backgroundColor: `${item.color}20` }]}>
          <item.icon size={22} color={item.color} />
        </View>
        <View style={styles.menuContent}>
          <Text style={styles.menuTitle}>{item.title}</Text>
          <Text style={styles.menuSubtitle}>{item.subtitle}</Text>
        </View>
        <ChevronRight size={18} color="#CD5C5C" />
      </TouchableOpacity>
    </Animated.View>
  );

  return (
    <LinearGradient
      colors={['#FF69B4', '#FFB6C1', '#FFC0CB']}
      style={styles.container}
    >
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <Animated.View
          entering={FadeInDown.springify()}
          style={styles.profileHeader}
        >
          <View style={styles.profileImageContainer}>
            <Image
              source={{ uri: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg' }}
              style={styles.profileImage}
            />
            <TouchableOpacity style={styles.editImageButton}>
              <Settings size={16} color="#8B0000" />
            </TouchableOpacity>
          </View>
          <Text style={styles.profileName}>Emma Wilson</Text>
          <Text style={styles.profileEmail}>emma.wilson@email.com</Text>
          <View style={styles.membershipBadge}>
            <Award size={16} color="#FFFACD" />
            <Text style={styles.membershipText}>Premium Member</Text>
          </View>
        </Animated.View>

        {/* Stats */}
        <Animated.View
          entering={FadeInDown.delay(200).springify()}
          style={styles.statsContainer}
        >
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>24</Text>
            <Text style={styles.statLabel}>Orders</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>12</Text>
            <Text style={styles.statLabel}>Wishlist</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>4.9</Text>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
        </Animated.View>

        {/* Achievements */}
        <Animated.View
          entering={FadeInDown.delay(400).springify()}
          style={styles.section}
        >
          <Text style={styles.sectionTitle}>Achievements</Text>
          <View style={styles.achievementsGrid}>
            {achievements.map((achievement, index) => (
              <View
                key={achievement.title}
                style={[
                  styles.achievementCard,
                  achievement.earned && styles.earnedAchievement,
                ]}
              >
                <Text style={styles.achievementIcon}>{achievement.icon}</Text>
                <Text
                  style={[
                    styles.achievementTitle,
                    achievement.earned && styles.earnedAchievementTitle,
                  ]}
                >
                  {achievement.title}
                </Text>
              </View>
            ))}
          </View>
        </Animated.View>

        {/* Menu Items */}
        <View style={styles.menuContainer}>
          {menuItems.map((item, index) => (
            <MenuItem key={item.title} item={item} index={index} />
          ))}
        </View>

        {/* Quick Settings */}
        <Animated.View
          entering={FadeInDown.delay(800).springify()}
          style={styles.quickSettings}
        >
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Bell size={20} color="#8B0000" />
              <Text style={styles.settingTitle}>Push Notifications</Text>
            </View>
            <Switch
              trackColor={{ false: '#FFB6C1', true: '#DC143C' }}
              thumbColor={notificationsEnabled ? '#FFFACD' : '#8B0000'}
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
            />
          </View>
        </Animated.View>

        {/* Logout Button */}
        <Animated.View
          entering={FadeInDown.delay(1000).springify()}
          style={styles.logoutContainer}
        >
          <TouchableOpacity style={styles.logoutButton}>
            <LogOut size={20} color="#DC143C" />
            <Text style={styles.logoutText}>Sign Out</Text>
          </TouchableOpacity>
        </Animated.View>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  profileHeader: {
    alignItems: 'center',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
  },
  profileImageContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 4,
    borderColor: '#FFFACD',
  },
  editImageButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#FFFACD',
    borderRadius: 15,
    padding: 6,
    borderWidth: 2,
    borderColor: '#FFB6C1',
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 16,
    color: '#8B0000',
    opacity: 0.8,
    marginBottom: 12,
  },
  membershipBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DC143C',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
  },
  membershipText: {
    fontSize: 12,
    color: '#FFFACD',
    fontWeight: '600',
    marginLeft: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    marginHorizontal: 20,
    borderRadius: 20,
    paddingVertical: 20,
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#CD5C5C',
  },
  statDivider: {
    width: 1,
    backgroundColor: '#FFB6C1',
    marginVertical: 10,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 15,
  },
  achievementsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  achievementCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    borderRadius: 15,
    padding: 15,
    alignItems: 'center',
    width: '47%',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  earnedAchievement: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderColor: '#FFFACD',
  },
  achievementIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  achievementTitle: {
    fontSize: 12,
    color: '#CD5C5C',
    textAlign: 'center',
    fontWeight: '500',
  },
  earnedAchievementTitle: {
    color: '#8B0000',
    fontWeight: '600',
  },
  menuContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 15,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  menuIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#8B0000',
    marginBottom: 2,
  },
  menuSubtitle: {
    fontSize: 13,
    color: '#CD5C5C',
  },
  quickSettings: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    marginHorizontal: 20,
    borderRadius: 15,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingTitle: {
    fontSize: 16,
    color: '#8B0000',
    fontWeight: '500',
    marginLeft: 12,
  },
  logoutContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 15,
    padding: 16,
    borderWidth: 1,
    borderColor: '#DC143C',
  },
  logoutText: {
    fontSize: 16,
    color: '#DC143C',
    fontWeight: '600',
    marginLeft: 8,
  },
  bottomSpacer: {
    height: 100,
  },
});