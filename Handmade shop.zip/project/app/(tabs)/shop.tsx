import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  FlatList,
  Dimensions,
} from 'react-native';
import { Search, Heart, Star, Grid2x2 as Grid, List } from 'lucide-react-native';
import Animated, {
  FadeInDown,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const products = [
  {
    id: 1,
    name: 'Silk Evening Dress',
    price: 299,
    image: 'https://images.pexels.com/photos/1936848/pexels-photo-1936848.jpeg',
    rating: 4.9,
    category: 'Dresses',
    isLiked: false,
  },
  {
    id: 2,
    name: 'Handwoven Scarf',
    price: 89,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg',
    rating: 4.8,
    category: 'Accessories',
    isLiked: true,
  },
  {
    id: 3,
    name: 'Artisan Jewelry Set',
    price: 159,
    image: 'https://images.pexels.com/photos/1927259/pexels-photo-1927259.jpeg',
    rating: 5.0,
    category: 'Jewelry',
    isLiked: false,
  },
  {
    id: 4,
    name: 'Embroidered Blouse',
    price: 135,
    image: 'https://images.pexels.com/photos/7679588/pexels-photo-7679588.jpeg',
    rating: 4.7,
    category: 'Tops',
    isLiked: true,
  },
  {
    id: 5,
    name: 'Leather Handbag',
    price: 245,
    image: 'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg',
    rating: 4.9,
    category: 'Accessories',
    isLiked: false,
  },
  {
    id: 6,
    name: 'Pearl Necklace',
    price: 189,
    image: 'https://images.pexels.com/photos/1616403/pexels-photo-1616403.jpeg',
    rating: 4.8,
    category: 'Jewelry',
    isLiked: true,
  },
];

const sortOptions = ['Price: Low to High', 'Price: High to Low', 'Highest Rated', 'Newest'];

export default function ShopScreen() {
  const [searchText, setSearchText] = useState('');
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [isGridView, setIsGridView] = useState(true);
  const [selectedSort, setSelectedSort] = useState('');
  const [productStates, setProductStates] = useState(products);

  const scaleValue = useSharedValue(1);

  useEffect(() => {
    filterProducts();
  }, [searchText]);

  const filterProducts = () => {
    let filtered = products.filter(product =>
      product.name.toLowerCase().includes(searchText.toLowerCase()) ||
      product.category.toLowerCase().includes(searchText.toLowerCase())
    );
    setFilteredProducts(filtered);
  };

  const toggleLike = (productId: number) => {
    setProductStates(prev =>
      prev.map(product =>
        product.id === productId
          ? { ...product, isLiked: !product.isLiked }
          : product
      )
    );
  };

  const sortProducts = (option: string) => {
    let sorted = [...filteredProducts];
    switch (option) {
      case 'Price: Low to High':
        sorted.sort((a, b) => a.price - b.price);
        break;
      case 'Price: High to Low':
        sorted.sort((a, b) => b.price - a.price);
        break;
      case 'Highest Rated':
        sorted.sort((a, b) => b.rating - a.rating);
        break;
      case 'Newest':
        sorted.sort((a, b) => b.id - a.id);
        break;
    }
    setFilteredProducts(sorted);
    setSelectedSort(option);
  };

  const ProductCard = ({ item, index }: { item: any; index: number }) => {
    const productState = productStates.find(p => p.id === item.id) || item;
    
    return (
      <Animated.View
        entering={FadeInDown.delay(index * 100).springify()}
        style={[
          styles.productCard,
          isGridView ? styles.gridCard : styles.listCard,
        ]}
      >
        <TouchableOpacity>
          <Image
            source={{ uri: item.image }}
            style={[
              styles.productImage,
              isGridView ? styles.gridImage : styles.listImage,
            ]}
          />
          <TouchableOpacity
            style={styles.likeButton}
            onPress={() => toggleLike(item.id)}
          >
            <Heart
              size={18}
              color={productState.isLiked ? '#DC143C' : '#8B0000'}
              fill={productState.isLiked ? '#DC143C' : 'transparent'}
            />
          </TouchableOpacity>
          <View style={styles.productInfo}>
            <Text style={styles.productName} numberOfLines={2}>
              {item.name}
            </Text>
            <Text style={styles.productCategory}>{item.category}</Text>
            <View style={styles.productFooter}>
              <Text style={styles.productPrice}>${item.price}</Text>
              <View style={styles.rating}>
                <Star size={10} color="#FFFACD" fill="#FFFACD" />
                <Text style={styles.ratingText}>{item.rating}</Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <LinearGradient
      colors={['#FF69B4', '#FFB6C1', '#FFC0CB']}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Handmade Shop</Text>
        <View style={styles.viewToggle}>
          <TouchableOpacity
            style={[styles.toggleButton, isGridView && styles.activeToggle]}
            onPress={() => setIsGridView(true)}
          >
            <Grid size={18} color={isGridView ? '#8B0000' : '#CD5C5C'} />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleButton, !isGridView && styles.activeToggle]}
            onPress={() => setIsGridView(false)}
          >
            <List size={18} color={!isGridView ? '#8B0000' : '#CD5C5C'} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color="#8B0000" />
          <TextInput
            placeholder="Search products..."
            placeholderTextColor="#CD5C5C"
            style={styles.searchInput}
            value={searchText}
            onChangeText={setSearchText}
          />
        </View>
      </View>

      {/* Sort Options */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.sortContainer}
      >
        {sortOptions.map((option) => (
          <TouchableOpacity
            key={option}
            style={[
              styles.sortButton,
              selectedSort === option && styles.activeSortButton,
            ]}
            onPress={() => sortProducts(option)}
          >
            <Text
              style={[
                styles.sortButtonText,
                selectedSort === option && styles.activeSortButtonText,
              ]}
            >
              {option}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Products Grid/List */}
      <FlatList
        data={filteredProducts}
        renderItem={({ item, index }) => <ProductCard item={item} index={index} />}
        keyExtractor={(item) => item.id.toString()}
        numColumns={isGridView ? 2 : 1}
        key={isGridView ? 'grid' : 'list'}
        contentContainerStyle={styles.productsList}
        showsVerticalScrollIndicator={false}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#8B0000',
  },
  viewToggle: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    padding: 4,
  },
  toggleButton: {
    padding: 8,
    borderRadius: 16,
  },
  activeToggle: {
    backgroundColor: '#FFFACD',
  },
  searchContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 25,
    paddingHorizontal: 20,
    paddingVertical: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: '#8B0000',
  },
  sortContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sortButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  activeSortButton: {
    backgroundColor: '#DC143C',
  },
  sortButtonText: {
    fontSize: 14,
    color: '#8B0000',
    fontWeight: '500',
  },
  activeSortButtonText: {
    color: '#FFFACD',
    fontWeight: '600',
  },
  productsList: {
    paddingHorizontal: 10,
    paddingBottom: 100,
  },
  productCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    margin: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 8,
  },
  gridCard: {
    flex: 1,
    maxWidth: width / 2 - 20,
  },
  listCard: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  productImage: {
    resizeMode: 'cover',
  },
  gridImage: {
    width: '100%',
    height: 160,
  },
  listImage: {
    width: 100,
    height: 100,
    borderRadius: 15,
    margin: 10,
  },
  likeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 15,
    padding: 6,
  },
  productInfo: {
    padding: 12,
    flex: 1,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 12,
    color: '#CD5C5C',
    marginBottom: 8,
  },
  productFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  productPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#DC143C',
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#8B0000',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
  },
  ratingText: {
    fontSize: 10,
    color: '#FFFACD',
    marginLeft: 3,
    fontWeight: '600',
  },
});